export default class DisplayTextSettings
{


}

